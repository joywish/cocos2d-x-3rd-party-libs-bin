Lua lpack
=============

This is a luajit implementation of lpack.
The original can be found here: http://www.tecgraf.puc-rio.br/~lhf/ftp/lua/#lpack